import { Component, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

import { FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import { CalendarOptions, DateSelectArg, EventClickArg, EventDropArg } from '@fullcalendar/core';

type Surveyor = { id: number; code: string; display_name: string; surveyor_type: string; current_status: string; home_lat?: number; home_lng?: number; };

type Toast = { id: number; type: 'success' | 'error' | 'warning' | 'info'; message: string; title?: string; };

type WorkloadDay = { date: string; dayName: string; count: number; };

type UpcomingAlert = { surveyorName: string; state: string; startTime: string; };

type ActivityLogEntry = { id: number; action: string; details: string; timestamp: Date; surveyorName?: string; };

type AppointmentTemplate = { id: number; name: string; duration: number; state: string; color: string; };

type SurveyorNote = { surveyorId: number; note: string; updatedAt: Date; };

type DashboardWidget = { id: string; title: string; type: 'stat' | 'chart' | 'list'; value?: number | string; data?: any[]; };

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, FullCalendarModule],
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  apiBase = (window as any).__API_BASE__ || 'http://localhost:8080/api';

  surveyors: Surveyor[] = [];
  allSurveyors: Surveyor[] = []; // All surveyors without status filter
  filteredSurveyors: Surveyor[] = [];
  selectedSurveyorId: number | 'ALL' = 'ALL';
  selectedSurveyorIds: number[] = [];
  selectedType: 'ALL' | 'INTERNAL' | 'EXTERNAL' = 'ALL';
  selectedCurrentStatus: 'ALL' | 'AVAILABLE' | 'BUSY' | 'OFFLINE' = 'ALL';
  surveyorMap: Map<number, Surveyor> = new Map();
  showSurveyorPicker = false;

  // Sidebar state
  sidebarCollapsed = false;
  searchQuery = '';

  // Loading states
  loadingSurveyors = true;
  loadingEvents = true;

  // Stats
  statsAvailable = 0;
  statsBusy = 0;
  statsOffline = 0;

  // Create Modal state
  showCreateModal = false;
  modalSurveyorName = '';
  modalDate = '';
  modalStartTime = '';
  modalEndTime = '';
  modalDuration = '';
  modalState = 'BUSY';
  private pendingStart = '';
  private pendingEnd = '';

  // Edit Modal state
  showEditModal = false;
  editId = 0;
  editSurveyorName = '';
  editDate = '';
  editStartTime = '';
  editEndTime = '';
  editDuration = '';
  editState = 'BUSY';
  editIsPast = false;
  private editPendingStart = '';
  private editPendingEnd = '';

  // Reschedule Confirmation Modal state
  showRescheduleModal = false;
  rescheduleEventId = '';
  rescheduleSurveyorName = '';
  rescheduleOldDate = '';
  rescheduleOldTime = '';
  rescheduleNewDate = '';
  rescheduleNewTime = '';
  rescheduleNewDuration = '';
  private reschedulePayload: any = null;
  private rescheduleRevertFn: (() => void) | null = null;

  // Success Confirmation Modal state
  showSuccessModal = false;
  successTitle = '';
  successMessage = '';
  successSurveyorName = '';
  successDate = '';
  successTime = '';
  successState = '';

  // Toast notifications
  toasts: Toast[] = [];
  private toastId = 0;

  // View toggle
  currentView: 'calendar' | 'timeline' | 'heatmap' | 'map' = 'calendar';

  // Upcoming alerts
  upcomingAlerts: UpcomingAlert[] = [];
  showAlertsPanel = false;

  // Workload heatmap data
  workloadData: Map<number, WorkloadDay[]> = new Map();
  heatmapWeekStart = new Date();

  // Map view
  mapSurveyors: Surveyor[] = [];

  // Recurring appointments
  modalRecurring = false;
  modalRecurringType: 'daily' | 'weekly' = 'weekly';
  modalRecurringCount = 4;

  // Conflict detection
  existingEvents: any[] = [];

  // Quick Add Button
  showQuickAddMenu = false;

  // Surveyor Grouping
  groupByType = true;
  collapsedGroups: Set<string> = new Set();

  // Appointment Templates
  templates: AppointmentTemplate[] = [
    { id: 1, name: 'Half Day', duration: 4, state: 'BUSY', color: '#e91e63' },
    { id: 2, name: 'Full Day', duration: 8, state: 'BUSY', color: '#9c27b0' },
    { id: 3, name: 'Quick Meeting', duration: 1, state: 'BUSY', color: '#2196f3' },
    { id: 4, name: 'Day Off', duration: 8, state: 'OFFLINE', color: '#607d8b' },
  ];
  showTemplateModal = false;
  selectedTemplate: AppointmentTemplate | null = null;

  // Mini Calendar Navigator
  miniCalendarDate = new Date();
  miniCalendarDays: { date: Date; isCurrentMonth: boolean; isToday: boolean; hasEvents: boolean; }[] = [];

  // Activity Log
  activityLog: ActivityLogEntry[] = [];
  showActivityLog = false;
  private activityLogId = 0;

  // Export
  showExportModal = false;
  exportFormat: 'pdf' | 'excel' | 'csv' = 'pdf';
  exportRange: 'week' | 'month' | 'custom' = 'week';

  // Real-time Updates
  lastSyncTime = new Date();
  isLiveSync = true;
  private syncInterval: any;

  // Capacity Indicators
  surveyorCapacity: Map<number, number> = new Map();
  maxDailyCapacity = 8; // hours

  // Resource Timeline
  timelineHours: string[] = [];
  timelineEvents: Map<number, any[]> = new Map();

  // Dashboard
  showDashboard = false;
  dashboardWidgets: DashboardWidget[] = [];

  // Appointment Coloring
  surveyorColors: Map<number, string> = new Map();
  showColorPicker = false;
  colorPickerSurveyorId = 0;
  customColors = ['#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107', '#ff9800', '#ff5722', '#795548'];

  // Surveyor Notes
  surveyorNotes: Map<number, SurveyorNote> = new Map();
  showNotesModal = false;
  notesModalSurveyorId = 0;
  notesModalSurveyorName = '';
  notesModalContent = '';

  calendarOptions: CalendarOptions = {
    plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay'
    },
    initialView: 'timeGridWeek',
    nowIndicator: true,
    weekends: true,
    selectable: true,
    selectMirror: true,
    editable: true,
    eventResizableFromStart: true,
    slotMinTime: '06:00:00',
    slotMaxTime: '22:00:00',
    scrollTime: '08:00:00',
    slotDuration: '00:30:00',
    events: [],
    select: this.handleDateSelect.bind(this),
    eventClick: this.handleEventClick.bind(this),
    eventDrop: this.handleEventDrop.bind(this),
    eventResize: this.handleEventResize.bind(this),
    eventColor: '#3788d8'
  };

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadAllSurveyors();
    this.loadSurveyors();
    this.refreshEvents();
    this.loadUpcomingAlerts();
    this.loadWorkloadData();
    this.buildMiniCalendar();
    this.initTimelineHours();
    this.initDashboard();
    this.loadSavedNotes();
    this.loadSavedColors();
  }

  // Load all surveyors for stats calculation
  loadAllSurveyors() {
    this.http.get<Surveyor[]>(`${this.apiBase}/surveyors`).subscribe({
      next: (rows) => {
        this.allSurveyors = rows;
        this.mapSurveyors = rows;
        // Populate surveyorMap with all surveyors for lookups
        rows.forEach(s => this.surveyorMap.set(s.id, s));
        this.calculateStats();
      },
      error: (e) => console.error(e)
    });
  }

  calculateStats() {
    this.statsAvailable = this.allSurveyors.filter(s => s.current_status === 'AVAILABLE').length;
    this.statsBusy = this.allSurveyors.filter(s => s.current_status === 'BUSY').length;
    this.statsOffline = this.allSurveyors.filter(s => s.current_status === 'OFFLINE').length;
  }

  // ============ TOAST NOTIFICATIONS ============
  showToast(type: 'success' | 'error' | 'warning' | 'info', message: string, title?: string) {
    const toast: Toast = { id: ++this.toastId, type, message, title };
    this.toasts.push(toast);
    setTimeout(() => this.removeToast(toast.id), 4000);
  }

  removeToast(id: number) {
    this.toasts = this.toasts.filter(t => t.id !== id);
  }

  // ============ VIEW TOGGLE ============
  setView(view: 'calendar' | 'timeline' | 'heatmap' | 'map') {
    this.currentView = view;
    if (view === 'heatmap') {
      this.loadWorkloadData();
    }
  }

  // ============ UPCOMING ALERTS ============
  loadUpcomingAlerts() {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    const dayAfter = new Date(tomorrow);
    dayAfter.setDate(dayAfter.getDate() + 1);

    this.http.get<any[]>(`${this.apiBase}/availability?from=${tomorrow.toISOString()}&to=${dayAfter.toISOString()}`).subscribe({
      next: (rows) => {
        this.upcomingAlerts = rows.map(r => {
          const surveyor = this.surveyorMap.get(r.surveyor_id) || this.allSurveyors.find(s => s.id === r.surveyor_id);
          return {
            surveyorName: surveyor?.display_name || `Surveyor ${r.surveyor_id}`,
            state: r.state,
            startTime: new Date(r.start_time).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
          };
        });
      },
      error: (e) => console.error(e)
    });
  }

  toggleAlertsPanel() {
    this.showAlertsPanel = !this.showAlertsPanel;
  }

  // ============ WORKLOAD HEATMAP ============
  loadWorkloadData() {
    const weekStart = new Date(this.heatmapWeekStart);
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    weekStart.setHours(0, 0, 0, 0);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 7);

    this.http.get<any[]>(`${this.apiBase}/availability?from=${weekStart.toISOString()}&to=${weekEnd.toISOString()}`).subscribe({
      next: (rows) => {
        const workloadMap = new Map<number, Map<string, number>>();

        rows.forEach(r => {
          const dateKey = new Date(r.start_time).toISOString().split('T')[0];
          if (!workloadMap.has(r.surveyor_id)) {
            workloadMap.set(r.surveyor_id, new Map());
          }
          const surveyorMap = workloadMap.get(r.surveyor_id)!;
          surveyorMap.set(dateKey, (surveyorMap.get(dateKey) || 0) + 1);
        });

        this.workloadData = new Map();
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

        this.allSurveyors.forEach(s => {
          const days: WorkloadDay[] = [];
          for (let i = 0; i < 7; i++) {
            const date = new Date(weekStart);
            date.setDate(date.getDate() + i);
            const dateKey = date.toISOString().split('T')[0];
            const count = workloadMap.get(s.id)?.get(dateKey) || 0;
            days.push({ date: dateKey, dayName: dayNames[i], count });
          }
          this.workloadData.set(s.id, days);
        });
      },
      error: (e) => console.error(e)
    });
  }

  getHeatmapColor(count: number): string {
    if (count === 0) return '#e8f5e9';
    if (count === 1) return '#c8e6c9';
    if (count === 2) return '#a5d6a7';
    if (count === 3) return '#81c784';
    if (count >= 4) return '#66bb6a';
    return '#e8f5e9';
  }

  prevHeatmapWeek() {
    this.heatmapWeekStart.setDate(this.heatmapWeekStart.getDate() - 7);
    this.loadWorkloadData();
  }

  nextHeatmapWeek() {
    this.heatmapWeekStart.setDate(this.heatmapWeekStart.getDate() + 7);
    this.loadWorkloadData();
  }

  getHeatmapWeekLabel(): string {
    const start = new Date(this.heatmapWeekStart);
    start.setDate(start.getDate() - start.getDay());
    const end = new Date(start);
    end.setDate(end.getDate() + 6);
    return `${start.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${end.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
  }

  // ============ CONFLICT DETECTION ============
  checkConflict(surveyorId: number, start: Date, end: Date): boolean {
    return this.existingEvents.some(e => {
      if (e.extendedProps?.surveyorId !== surveyorId) return false;
      const eStart = new Date(e.start);
      const eEnd = new Date(e.end);
      return (start < eEnd && end > eStart);
    });
  }

  loadSurveyors() {
    this.loadingSurveyors = true;
    let params: string[] = [];
    if (this.selectedType !== 'ALL') {
      params.push(`type=${this.selectedType}`);
    }
    if (this.selectedCurrentStatus !== 'ALL') {
      params.push(`currentStatus=${this.selectedCurrentStatus}`);
    }
    const queryString = params.length > 0 ? `?${params.join('&')}` : '';

    this.http.get<Surveyor[]>(`${this.apiBase}/surveyors${queryString}`).subscribe({
      next: (rows) => {
        this.surveyors = rows;
        this.applySearchFilter();
        this.surveyorMap = new Map(rows.map(s => [s.id, s]));
        // Reset selection when filters change
        this.selectedSurveyorIds = [];
        this.selectedSurveyorId = 'ALL';
        this.loadingSurveyors = false;
      },
      error: (e) => {
        console.error(e);
        this.loadingSurveyors = false;
      }
    });
  }

  applySearchFilter() {
    if (!this.searchQuery.trim()) {
      this.filteredSurveyors = this.surveyors;
    } else {
      const query = this.searchQuery.toLowerCase();
      this.filteredSurveyors = this.surveyors.filter(s =>
        s.display_name.toLowerCase().includes(query) ||
        s.code.toLowerCase().includes(query)
      );
    }
  }

  onSearchChange() {
    this.applySearchFilter();
  }

  // Generate avatar initials and color
  getInitials(name: string): string {
    return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
  }

  getAvatarColor(name: string): string {
    const colors = ['#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#00bcd4', '#009688', '#4caf50', '#ff9800', '#ff5722'];
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  }

  toggleSidebar() {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  // Quick filter pills
  quickFilterAvailable() {
    this.selectedCurrentStatus = 'AVAILABLE';
    this.loadSurveyors();
  }

  quickFilterInternal() {
    this.selectedType = 'INTERNAL';
    this.selectedCurrentStatus = 'ALL';
    this.loadSurveyors();
  }

  quickFilterExternal() {
    this.selectedType = 'EXTERNAL';
    this.selectedCurrentStatus = 'ALL';
    this.loadSurveyors();
  }

  clearFilters() {
    this.selectedType = 'ALL';
    this.selectedCurrentStatus = 'ALL';
    this.searchQuery = '';
    this.loadSurveyors();
  }

  hasActiveFilters(): boolean {
    return this.selectedType !== 'ALL' || this.selectedCurrentStatus !== 'ALL' || this.searchQuery.trim() !== '';
  }

  // Select surveyor from sidebar
  selectSurveyor(id: number) {
    this.toggleSurveyorSelection(id);
  }

  onTypeChange(type: string) {
    this.selectedType = type as 'ALL' | 'INTERNAL' | 'EXTERNAL';
    this.loadSurveyors();
  }

  onCurrentStatusChange(status: string) {
    this.selectedCurrentStatus = status as 'ALL' | 'AVAILABLE' | 'BUSY' | 'OFFLINE';
    this.loadSurveyors();
  }

  getCurrentStatusColor(status: string): string {
    switch (status) {
      case 'AVAILABLE': return '#28a745';
      case 'BUSY': return '#dc3545';
      case 'OFFLINE': return '#6c757d';
      default: return '#3788d8';
    }
  }

  toggleSurveyorPicker() {
    this.showSurveyorPicker = !this.showSurveyorPicker;
  }

  closeSurveyorPicker() {
    this.showSurveyorPicker = false;
  }

  toggleSurveyorSelection(id: number) {
    const index = this.selectedSurveyorIds.indexOf(id);
    if (index > -1) {
      this.selectedSurveyorIds.splice(index, 1);
    } else {
      this.selectedSurveyorIds.push(id);
    }
    this.selectedSurveyorId = 'ALL'; // Reset single selection when multi-selecting
    this.refreshEvents();
  }

  isSurveyorSelected(id: number): boolean {
    return this.selectedSurveyorIds.includes(id);
  }

  selectAllSurveyors() {
    this.selectedSurveyorIds = this.filteredSurveyors.map(s => s.id);
    this.selectedSurveyorId = 'ALL';
    this.refreshEvents();
  }

  clearAllSurveyors() {
    this.selectedSurveyorIds = [];
    this.selectedSurveyorId = 'ALL';
    this.refreshEvents();
  }

  getSelectedSurveyorNames(): string {
    if (this.selectedSurveyorIds.length === 0) {
      return 'All Surveyors';
    }
    if (this.selectedSurveyorIds.length <= 3) {
      return this.selectedSurveyorIds
        .map(id => this.surveyorMap.get(id)?.display_name || `Surveyor ${id}`)
        .join(', ');
    }
    return `${this.selectedSurveyorIds.length} surveyors selected`;
  }

  refreshEvents() {
    this.loadingEvents = true;
    const from = new Date();
    from.setDate(from.getDate() - 7);
    const to = new Date();
    to.setDate(to.getDate() + 30);

    const fromIso = from.toISOString();
    const toIso = to.toISOString();

    let q = `${this.apiBase}/availability?from=${encodeURIComponent(fromIso)}&to=${encodeURIComponent(toIso)}`;

    // Use multi-select if any surveyors are selected
    if (this.selectedSurveyorIds.length > 0) {
      q += `&surveyorIds=${this.selectedSurveyorIds.join(',')}`;
    } else if (this.selectedSurveyorId !== 'ALL') {
      q += `&surveyorId=${this.selectedSurveyorId}`;
    }

    this.http.get<any[]>(q).subscribe({
      next: (rows) => {
        const evs = rows.map(r => {
          const surveyor = this.surveyorMap.get(r.surveyor_id);
          const name = surveyor ? surveyor.display_name : `Surveyor ${r.surveyor_id}`;
          const isPast = new Date(r.end_time) < new Date();
          return {
            id: String(r.id),
            title: `${name} - ${r.state}`,
            start: r.start_time,
            end: r.end_time,
            backgroundColor: isPast ? this.getPastStateColor(r.state) : this.getStateColor(r.state),
            borderColor: isPast ? this.getPastStateColor(r.state) : this.getStateColor(r.state),
            editable: !isPast,
            extendedProps: { state: r.state, source: r.source, surveyorId: r.surveyor_id, isPast }
          };
        });
        this.existingEvents = evs; // Store for conflict detection
        this.calendarOptions = { ...this.calendarOptions, events: evs };
        this.loadingEvents = false;
        // Refresh stats after events load
        this.loadAllSurveyors();
      },
      error: (e) => {
        console.error(e);
        this.loadingEvents = false;
      }
    });
  }

  getStateColor(state: string): string {
    switch (state) {
      case 'BUSY': return '#dc3545';
      case 'OFFLINE': return '#6c757d';
      default: return '#3788d8';
    }
  }

  getPastStateColor(state: string): string {
    switch (state) {
      case 'BUSY': return '#cd5c5c';
      case 'OFFLINE': return '#a9a9a9';
      default: return '#87ceeb';
    }
  }

  isPastDate(date: Date): boolean {
    const now = new Date();
    return date < now;
  }

  // CREATE MODAL
  handleDateSelect(selectInfo: DateSelectArg) {
    // Require exactly one surveyor selected for creation
    if (this.selectedSurveyorIds.length === 0 && this.selectedSurveyorId === 'ALL') {
      this.showToast('warning', 'Please select exactly one surveyor to create an appointment.');
      selectInfo.view.calendar.unselect();
      return;
    }

    if (this.selectedSurveyorIds.length > 1) {
      this.showToast('warning', 'Please select only one surveyor to create an appointment.');
      selectInfo.view.calendar.unselect();
      return;
    }

    const startDate = selectInfo.start;

    // Check if trying to create in the past
    if (this.isPastDate(startDate)) {
      this.showToast('error', 'Cannot create appointments in the past.');
      selectInfo.view.calendar.unselect();
      return;
    }

    // Determine which surveyor to use
    const surveyorIdToUse = this.selectedSurveyorIds.length === 1
      ? this.selectedSurveyorIds[0]
      : this.selectedSurveyorId as number;

    const surveyor = this.surveyorMap.get(surveyorIdToUse);
    this.modalSurveyorName = surveyor ? surveyor.display_name : `Surveyor ${surveyorIdToUse}`;

    let endDate = selectInfo.end;

    const durationMs = endDate.getTime() - startDate.getTime();
    if (durationMs < 60 * 60 * 1000) {
      endDate = new Date(startDate.getTime() + 60 * 60 * 1000);
    }

    // Check for conflicts
    if (this.checkConflict(surveyorIdToUse, startDate, endDate)) {
      this.showToast('warning', 'This time slot overlaps with an existing appointment. You can still create it if needed.');
    }

    this.pendingStart = startDate.toISOString();
    this.pendingEnd = endDate.toISOString();

    this.modalDate = this.formatDate(startDate);
    this.modalStartTime = this.formatTime(startDate);
    this.modalEndTime = this.formatTime(endDate);
    this.modalDuration = this.formatDuration(startDate, endDate);
    this.modalState = 'BUSY';
    this.modalRecurring = false;
    this.modalRecurringType = 'weekly';
    this.modalRecurringCount = 4;

    this.showCreateModal = true;
    selectInfo.view.calendar.unselect();
  }

  closeCreateModal() {
    this.showCreateModal = false;
    this.modalRecurring = false;
  }

  confirmCreate() {
    const surveyorIdToUse = this.selectedSurveyorIds.length === 1
      ? this.selectedSurveyorIds[0]
      : this.selectedSurveyorId as number;

    if (this.modalRecurring) {
      this.createRecurringAvailability(
        surveyorIdToUse,
        this.pendingStart,
        this.pendingEnd,
        this.modalState,
        this.modalRecurringType,
        this.modalRecurringCount
      );
    } else {
      this.createAvailability(
        surveyorIdToUse,
        this.pendingStart,
        this.pendingEnd,
        this.modalState
      );
    }
    this.showCreateModal = false;
  }

  createRecurringAvailability(surveyorId: number, start: string, end: string, state: string, recurringType: 'daily' | 'weekly', count: number) {
    const blocks: { startTime: string; endTime: string; state: string }[] = [];
    const startDate = new Date(start);
    const endDate = new Date(end);
    const durationMs = endDate.getTime() - startDate.getTime();
    const dayIncrement = recurringType === 'daily' ? 1 : 7;

    for (let i = 0; i < count; i++) {
      const blockStart = new Date(startDate.getTime() + (i * dayIncrement * 24 * 60 * 60 * 1000));
      const blockEnd = new Date(blockStart.getTime() + durationMs);
      blocks.push({
        startTime: blockStart.toISOString(),
        endTime: blockEnd.toISOString(),
        state: state
      });
    }

    const payload = { surveyorId, blocks };
    const surveyor = this.surveyorMap.get(surveyorId);
    const surveyorName = surveyor ? surveyor.display_name : `Surveyor ${surveyorId}`;

    this.http.post(`${this.apiBase}/mobile/availability`, payload).subscribe({
      next: () => {
        this.refreshEvents();
        this.loadUpcomingAlerts();
        this.showToast('success', `Created ${count} recurring ${state.toLowerCase()} appointments for ${surveyorName}`);
      },
      error: (e) => {
        console.error(e);
        this.showToast('error', 'Failed to create recurring appointments');
      }
    });
  }

  createAvailability(surveyorId: number, start: string, end: string, state: string) {
    const payload = {
      surveyorId: surveyorId,
      blocks: [{ startTime: start, endTime: end, state: state }]
    };

    const surveyor = this.surveyorMap.get(surveyorId);
    const surveyorName = surveyor ? surveyor.display_name : `Surveyor ${surveyorId}`;
    const startDate = new Date(start);
    const endDate = new Date(end);

    this.http.post(`${this.apiBase}/mobile/availability`, payload).subscribe({
      next: () => {
        this.refreshEvents();
        this.loadUpcomingAlerts();
        // Show success modal
        this.successTitle = 'Appointment Created';
        this.successMessage = 'The appointment has been successfully created.';
        this.successSurveyorName = surveyorName;
        this.successDate = this.formatDate(startDate);
        this.successTime = `${this.formatTime(startDate)} - ${this.formatTime(endDate)}`;
        this.successState = state;
        this.showSuccessModal = true;
      },
      error: (e) => {
        console.error(e);
        alert('Failed to create appointment');
      }
    });
  }

  closeSuccessModal() {
    this.showSuccessModal = false;
  }

  // EDIT MODAL
  handleEventClick(clickInfo: EventClickArg) {
    const event = clickInfo.event;
    const surveyorId = event.extendedProps['surveyorId'];
    const surveyor = this.surveyorMap.get(surveyorId);
    const isPast = event.extendedProps['isPast'] || false;

    this.editId = Number(event.id);
    this.editSurveyorName = surveyor ? surveyor.display_name : `Surveyor ${surveyorId}`;
    this.editState = event.extendedProps['state'];
    this.editIsPast = isPast;

    const startDate = event.start!;
    const endDate = event.end!;

    this.editPendingStart = startDate.toISOString();
    this.editPendingEnd = endDate.toISOString();

    this.editDate = this.formatDate(startDate);
    this.editStartTime = this.formatTime(startDate);
    this.editEndTime = this.formatTime(endDate);
    this.editDuration = this.formatDuration(startDate, endDate);

    this.showEditModal = true;
  }

  closeEditModal() {
    this.showEditModal = false;
  }

  confirmUpdate() {
    if (this.editIsPast) {
      alert('Cannot modify past appointments.');
      return;
    }

    const payload = {
      startTime: this.editPendingStart,
      endTime: this.editPendingEnd,
      state: this.editState
    };

    this.http.put(`${this.apiBase}/availability/${this.editId}`, payload).subscribe({
      next: () => {
        this.showEditModal = false;
        this.refreshEvents();
      },
      error: (e) => {
        console.error(e);
        alert('Failed to update appointment');
      }
    });
  }

  confirmDelete() {
    if (this.editIsPast) {
      alert('Cannot delete past appointments.');
      return;
    }

    if (confirm('Are you sure you want to delete this appointment?')) {
      this.http.delete(`${this.apiBase}/availability/${this.editId}`).subscribe({
        next: () => {
          this.showEditModal = false;
          this.refreshEvents();
        },
        error: (e) => {
          console.error(e);
          alert('Failed to delete appointment');
        }
      });
    }
  }

  // DRAG & RESIZE with Confirmation
  handleEventDrop(dropInfo: EventDropArg) {
    const event = dropInfo.event;
    const oldEvent = dropInfo.oldEvent;

    // Check if this is a past event
    if (event.extendedProps['isPast']) {
      dropInfo.revert();
      alert('Cannot reschedule past appointments.');
      return;
    }

    // Check if trying to move to past
    if (this.isPastDate(event.start!)) {
      dropInfo.revert();
      alert('Cannot reschedule appointment to a past date/time.');
      return;
    }

    const surveyorId = event.extendedProps['surveyorId'];
    const surveyor = this.surveyorMap.get(surveyorId);

    this.rescheduleEventId = event.id;
    this.rescheduleSurveyorName = surveyor ? surveyor.display_name : `Surveyor ${surveyorId}`;
    this.rescheduleOldDate = this.formatDate(oldEvent.start!);
    this.rescheduleOldTime = `${this.formatTime(oldEvent.start!)} - ${this.formatTime(oldEvent.end!)}`;
    this.rescheduleNewDate = this.formatDate(event.start!);
    this.rescheduleNewTime = `${this.formatTime(event.start!)} - ${this.formatTime(event.end!)}`;
    this.rescheduleNewDuration = this.formatDuration(event.start!, event.end!);

    this.reschedulePayload = {
      startTime: event.start!.toISOString(),
      endTime: event.end!.toISOString(),
      state: event.extendedProps['state']
    };
    this.rescheduleRevertFn = () => dropInfo.revert();

    this.showRescheduleModal = true;
  }

  handleEventResize(resizeInfo: any) {
    const event = resizeInfo.event;
    const oldEvent = resizeInfo.oldEvent;

    // Check if this is a past event
    if (event.extendedProps['isPast']) {
      resizeInfo.revert();
      alert('Cannot resize past appointments.');
      return;
    }

    const surveyorId = event.extendedProps['surveyorId'];
    const surveyor = this.surveyorMap.get(surveyorId);

    this.rescheduleEventId = event.id;
    this.rescheduleSurveyorName = surveyor ? surveyor.display_name : `Surveyor ${surveyorId}`;
    this.rescheduleOldDate = this.formatDate(oldEvent.start!);
    this.rescheduleOldTime = `${this.formatTime(oldEvent.start!)} - ${this.formatTime(oldEvent.end!)}`;
    this.rescheduleNewDate = this.formatDate(event.start!);
    this.rescheduleNewTime = `${this.formatTime(event.start!)} - ${this.formatTime(event.end!)}`;
    this.rescheduleNewDuration = this.formatDuration(event.start!, event.end!);

    this.reschedulePayload = {
      startTime: event.start!.toISOString(),
      endTime: event.end!.toISOString(),
      state: event.extendedProps['state']
    };
    this.rescheduleRevertFn = () => resizeInfo.revert();

    this.showRescheduleModal = true;
  }

  closeRescheduleModal() {
    if (this.rescheduleRevertFn) {
      this.rescheduleRevertFn();
    }
    this.showRescheduleModal = false;
    this.reschedulePayload = null;
    this.rescheduleRevertFn = null;
  }

  confirmReschedule() {
    if (!this.reschedulePayload) return;

    this.http.put(`${this.apiBase}/availability/${this.rescheduleEventId}`, this.reschedulePayload).subscribe({
      next: () => {
        this.showRescheduleModal = false;
        this.reschedulePayload = null;
        this.rescheduleRevertFn = null;
        this.refreshEvents();
      },
      error: (e) => {
        console.error(e);
        if (this.rescheduleRevertFn) {
          this.rescheduleRevertFn();
        }
        this.showRescheduleModal = false;
        this.reschedulePayload = null;
        this.rescheduleRevertFn = null;
        alert('Failed to reschedule appointment');
      }
    });
  }

  // HELPERS
  formatDate(date: Date): string {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }

  formatTime(date: Date): string {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  }

  formatDuration(start: Date, end: Date): string {
    const diffMs = end.getTime() - start.getTime();
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    if (hours === 0) return `${minutes} min`;
    if (minutes === 0) return hours === 1 ? '1 hour' : `${hours} hours`;
    return `${hours}h ${minutes}m`;
  }

  onSurveyorChange(val: string) {
    this.selectedSurveyorId = val === 'ALL' ? 'ALL' : Number(val);
    this.refreshEvents();
  }

  // ============ QUICK ADD BUTTON ============
  toggleQuickAddMenu() {
    this.showQuickAddMenu = !this.showQuickAddMenu;
  }

  quickAddFromTemplate(template: AppointmentTemplate) {
    if (this.selectedSurveyorIds.length !== 1) {
      this.showToast('warning', 'Please select exactly one surveyor first');
      this.showQuickAddMenu = false;
      return;
    }

    const surveyorId = this.selectedSurveyorIds[0];
    const now = new Date();
    now.setMinutes(0, 0, 0);
    now.setHours(now.getHours() + 1);

    const start = now.toISOString();
    const end = new Date(now.getTime() + template.duration * 60 * 60 * 1000).toISOString();

    this.createAvailability(surveyorId, start, end, template.state);
    this.addActivityLog('Created', `${template.name} appointment`);
    this.showQuickAddMenu = false;
  }

  openQuickAddModal() {
    if (this.selectedSurveyorIds.length !== 1) {
      this.showToast('warning', 'Please select exactly one surveyor first');
      return;
    }
    this.showTemplateModal = true;
    this.showQuickAddMenu = false;
  }

  // ============ SURVEYOR GROUPING ============
  toggleGrouping() {
    this.groupByType = !this.groupByType;
  }

  toggleGroup(group: string) {
    if (this.collapsedGroups.has(group)) {
      this.collapsedGroups.delete(group);
    } else {
      this.collapsedGroups.add(group);
    }
  }

  isGroupCollapsed(group: string): boolean {
    return this.collapsedGroups.has(group);
  }

  getGroupedSurveyors(): { type: string; surveyors: Surveyor[] }[] {
    if (!this.groupByType) {
      return [{ type: 'ALL', surveyors: this.filteredSurveyors }];
    }
    const groups: { [key: string]: Surveyor[] } = {};
    this.filteredSurveyors.forEach(s => {
      const type = s.surveyor_type || 'OTHER';
      if (!groups[type]) groups[type] = [];
      groups[type].push(s);
    });
    return Object.keys(groups).sort().map(type => ({ type, surveyors: groups[type] }));
  }

  // Get internal surveyors (filtered)
  getInternalSurveyors(): Surveyor[] {
    return this.filteredSurveyors.filter(s => s.surveyor_type === 'INTERNAL');
  }

  // Get external surveyors (filtered)
  getExternalSurveyors(): Surveyor[] {
    return this.filteredSurveyors.filter(s => s.surveyor_type === 'EXTERNAL');
  }

  // ============ APPOINTMENT TEMPLATES ============
  selectTemplate(template: AppointmentTemplate) {
    this.selectedTemplate = template;
  }

  applyTemplate() {
    if (!this.selectedTemplate) return;
    this.quickAddFromTemplate(this.selectedTemplate);
    this.showTemplateModal = false;
    this.selectedTemplate = null;
  }

  closeTemplateModal() {
    this.showTemplateModal = false;
    this.selectedTemplate = null;
  }

  // ============ MINI CALENDAR NAVIGATOR ============
  buildMiniCalendar() {
    const year = this.miniCalendarDate.getFullYear();
    const month = this.miniCalendarDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const days: { date: Date; isCurrentMonth: boolean; isToday: boolean; hasEvents: boolean }[] = [];

    // Previous month days
    const startDayOfWeek = firstDay.getDay();
    for (let i = startDayOfWeek - 1; i >= 0; i--) {
      const date = new Date(year, month, -i);
      days.push({ date, isCurrentMonth: false, isToday: false, hasEvents: false });
    }

    // Current month days
    for (let d = 1; d <= lastDay.getDate(); d++) {
      const date = new Date(year, month, d);
      const isToday = date.getTime() === today.getTime();
      days.push({ date, isCurrentMonth: true, isToday, hasEvents: false });
    }

    // Next month days to fill grid
    const remaining = 42 - days.length;
    for (let i = 1; i <= remaining; i++) {
      const date = new Date(year, month + 1, i);
      days.push({ date, isCurrentMonth: false, isToday: false, hasEvents: false });
    }

    this.miniCalendarDays = days;
  }

  prevMiniMonth() {
    this.miniCalendarDate = new Date(this.miniCalendarDate.getFullYear(), this.miniCalendarDate.getMonth() - 1, 1);
    this.buildMiniCalendar();
  }

  nextMiniMonth() {
    this.miniCalendarDate = new Date(this.miniCalendarDate.getFullYear(), this.miniCalendarDate.getMonth() + 1, 1);
    this.buildMiniCalendar();
  }

  getMiniMonthLabel(): string {
    return this.miniCalendarDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  }

  navigateToDate(date: Date) {
    // This would navigate the main calendar to the selected date
    this.calendarOptions = {
      ...this.calendarOptions,
      initialDate: date
    };
    this.showToast('info', `Navigated to ${this.formatDate(date)}`);
  }

  // ============ ACTIVITY LOG ============
  addActivityLog(action: string, details: string, surveyorName?: string) {
    const entry: ActivityLogEntry = {
      id: ++this.activityLogId,
      action,
      details,
      timestamp: new Date(),
      surveyorName
    };
    this.activityLog.unshift(entry);
    if (this.activityLog.length > 100) {
      this.activityLog = this.activityLog.slice(0, 100);
    }
  }

  toggleActivityLog() {
    this.showActivityLog = !this.showActivityLog;
  }

  getActivityIcon(action: string): string {
    switch (action.toLowerCase()) {
      case 'created': return '➕';
      case 'updated': return '✏️';
      case 'deleted': return '🗑️';
      case 'rescheduled': return '📅';
      default: return '📋';
    }
  }

  formatActivityTime(date: Date): string {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return date.toLocaleDateString();
  }

  // ============ EXPORT ============
  openExportModal() {
    this.showExportModal = true;
  }

  closeExportModal() {
    this.showExportModal = false;
  }

  exportSchedule() {
    const data = this.prepareExportData();

    if (this.exportFormat === 'csv') {
      this.exportAsCSV(data);
    } else if (this.exportFormat === 'excel') {
      this.exportAsExcel(data);
    } else {
      this.exportAsPDF(data);
    }

    this.showExportModal = false;
    this.addActivityLog('Exported', `Schedule as ${this.exportFormat.toUpperCase()}`);
    this.showToast('success', `Schedule exported as ${this.exportFormat.toUpperCase()}`);
  }

  prepareExportData(): any[] {
    return this.existingEvents.map(e => ({
      surveyor: e.title.split(' - ')[0],
      status: e.extendedProps.state,
      start: new Date(e.start).toLocaleString(),
      end: new Date(e.end).toLocaleString(),
    }));
  }

  exportAsCSV(data: any[]) {
    const headers = ['Surveyor', 'Status', 'Start', 'End'];
    const rows = data.map(d => [d.surveyor, d.status, d.start, d.end]);
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    this.downloadFile(csv, 'schedule.csv', 'text/csv');
  }

  exportAsExcel(data: any[]) {
    // Simple HTML table that Excel can open
    let html = '<table><tr><th>Surveyor</th><th>Status</th><th>Start</th><th>End</th></tr>';
    data.forEach(d => {
      html += `<tr><td>${d.surveyor}</td><td>${d.status}</td><td>${d.start}</td><td>${d.end}</td></tr>`;
    });
    html += '</table>';
    this.downloadFile(html, 'schedule.xls', 'application/vnd.ms-excel');
  }

  exportAsPDF(data: any[]) {
    // Create printable HTML
    let html = `<html><head><title>Schedule Export</title>
      <style>body{font-family:Arial;} table{width:100%;border-collapse:collapse;}
      th,td{border:1px solid #ddd;padding:8px;text-align:left;} th{background:#3949ab;color:white;}</style>
      </head><body><h1>Surveyor Schedule</h1><p>Exported: ${new Date().toLocaleString()}</p>
      <table><tr><th>Surveyor</th><th>Status</th><th>Start</th><th>End</th></tr>`;
    data.forEach(d => {
      html += `<tr><td>${d.surveyor}</td><td>${d.status}</td><td>${d.start}</td><td>${d.end}</td></tr>`;
    });
    html += '</table></body></html>';

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(html);
      printWindow.document.close();
      printWindow.print();
    }
  }

  downloadFile(content: string, filename: string, mimeType: string) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  // ============ REAL-TIME UPDATES ============
  startLiveSync() {
    if (this.syncInterval) clearInterval(this.syncInterval);
    this.syncInterval = setInterval(() => {
      if (this.isLiveSync) {
        this.refreshEvents();
        this.lastSyncTime = new Date();
      }
    }, 30000); // Sync every 30 seconds
  }

  toggleLiveSync() {
    this.isLiveSync = !this.isLiveSync;
    this.showToast('info', this.isLiveSync ? 'Live sync enabled' : 'Live sync disabled');
  }

  getLastSyncLabel(): string {
    const diff = new Date().getTime() - this.lastSyncTime.getTime();
    if (diff < 60000) return 'Just now';
    return `${Math.floor(diff / 60000)}m ago`;
  }

  // ============ CAPACITY INDICATORS ============
  calculateCapacity() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    this.surveyorCapacity.clear();

    this.existingEvents.forEach(e => {
      const start = new Date(e.start);
      const end = new Date(e.end);
      if (start >= today && start < tomorrow) {
        const surveyorId = e.extendedProps.surveyorId;
        const hours = (end.getTime() - start.getTime()) / (1000 * 60 * 60);
        const current = this.surveyorCapacity.get(surveyorId) || 0;
        this.surveyorCapacity.set(surveyorId, current + hours);
      }
    });
  }

  getCapacityPercent(surveyorId: number): number {
    const hours = this.surveyorCapacity.get(surveyorId) || 0;
    return Math.min(100, (hours / this.maxDailyCapacity) * 100);
  }

  getCapacityColor(surveyorId: number): string {
    const percent = this.getCapacityPercent(surveyorId);
    if (percent < 50) return '#4caf50';
    if (percent < 80) return '#ff9800';
    return '#f44336';
  }

  getCapacityLabel(surveyorId: number): string {
    const hours = this.surveyorCapacity.get(surveyorId) || 0;
    return `${hours.toFixed(1)}h / ${this.maxDailyCapacity}h`;
  }

  // ============ RESOURCE TIMELINE ============
  initTimelineHours() {
    this.timelineHours = [];
    for (let h = 6; h <= 22; h++) {
      this.timelineHours.push(`${h.toString().padStart(2, '0')}:00`);
    }
  }

  getTimelinePosition(time: string): number {
    const date = new Date(time);
    const hours = date.getHours() + date.getMinutes() / 60;
    return ((hours - 6) / 16) * 100; // 6am to 10pm = 16 hours
  }

  getTimelineWidth(start: string, end: string): number {
    const startDate = new Date(start);
    const endDate = new Date(end);
    const duration = (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60);
    return (duration / 16) * 100;
  }

  getTimelineEventsForSurveyor(surveyorId: number): any[] {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    return this.existingEvents.filter(e => {
      if (e.extendedProps.surveyorId !== surveyorId) return false;
      const start = new Date(e.start);
      return start >= today && start < tomorrow;
    });
  }

  // ============ DASHBOARD ============
  initDashboard() {
    this.dashboardWidgets = [
      { id: 'total', title: 'Total Surveyors', type: 'stat', value: 0 },
      { id: 'available', title: 'Available Now', type: 'stat', value: 0 },
      { id: 'appointments', title: 'Today\'s Appointments', type: 'stat', value: 0 },
      { id: 'utilization', title: 'Avg Utilization', type: 'stat', value: '0%' },
    ];
  }

  toggleDashboard() {
    this.showDashboard = !this.showDashboard;
    if (this.showDashboard) {
      this.updateDashboard();
    }
  }

  updateDashboard() {
    this.calculateCapacity();

    const totalCapacity = this.allSurveyors.length * this.maxDailyCapacity;
    let usedHours = 0;
    this.surveyorCapacity.forEach(h => usedHours += h);
    const utilization = totalCapacity > 0 ? Math.round((usedHours / totalCapacity) * 100) : 0;

    const todayEvents = this.existingEvents.filter(e => {
      const start = new Date(e.start);
      const today = new Date();
      return start.toDateString() === today.toDateString();
    });

    this.dashboardWidgets = [
      { id: 'total', title: 'Total Surveyors', type: 'stat', value: this.allSurveyors.length },
      { id: 'available', title: 'Available Now', type: 'stat', value: this.statsAvailable },
      { id: 'appointments', title: 'Today\'s Appointments', type: 'stat', value: todayEvents.length },
      { id: 'utilization', title: 'Avg Utilization', type: 'stat', value: `${utilization}%` },
    ];
  }

  // ============ APPOINTMENT COLORING ============
  openColorPicker(surveyorId: number) {
    this.colorPickerSurveyorId = surveyorId;
    this.showColorPicker = true;
  }

  closeColorPicker() {
    this.showColorPicker = false;
    this.colorPickerSurveyorId = 0;
  }

  selectColor(color: string) {
    this.surveyorColors.set(this.colorPickerSurveyorId, color);
    this.saveColors();
    this.refreshEvents();
    this.showColorPicker = false;
    this.showToast('success', 'Color updated');
  }

  getSurveyorColor(surveyorId: number): string {
    return this.surveyorColors.get(surveyorId) || this.getAvatarColor(this.surveyorMap.get(surveyorId)?.display_name || '');
  }

  saveColors() {
    const colors: { [key: number]: string } = {};
    this.surveyorColors.forEach((v, k) => colors[k] = v);
    localStorage.setItem('surveyorColors', JSON.stringify(colors));
  }

  loadSavedColors() {
    const saved = localStorage.getItem('surveyorColors');
    if (saved) {
      const colors = JSON.parse(saved);
      Object.keys(colors).forEach(k => {
        this.surveyorColors.set(Number(k), colors[k]);
      });
    }
  }

  // ============ SURVEYOR NOTES ============
  openNotesModal(surveyorId: number) {
    const surveyor = this.surveyorMap.get(surveyorId) || this.allSurveyors.find(s => s.id === surveyorId);
    this.notesModalSurveyorId = surveyorId;
    this.notesModalSurveyorName = surveyor?.display_name || `Surveyor ${surveyorId}`;
    this.notesModalContent = this.surveyorNotes.get(surveyorId)?.note || '';
    this.showNotesModal = true;
  }

  closeNotesModal() {
    this.showNotesModal = false;
    this.notesModalSurveyorId = 0;
    this.notesModalContent = '';
  }

  saveNote() {
    if (this.notesModalSurveyorId) {
      this.surveyorNotes.set(this.notesModalSurveyorId, {
        surveyorId: this.notesModalSurveyorId,
        note: this.notesModalContent,
        updatedAt: new Date()
      });
      this.saveNotes();
      this.showToast('success', 'Note saved');
      this.addActivityLog('Updated', 'Surveyor note', this.notesModalSurveyorName);
    }
    this.closeNotesModal();
  }

  hasNote(surveyorId: number): boolean {
    const note = this.surveyorNotes.get(surveyorId);
    return note ? note.note.trim().length > 0 : false;
  }

  saveNotes() {
    const notes: { [key: number]: { note: string; updatedAt: string } } = {};
    this.surveyorNotes.forEach((v, k) => {
      notes[k] = { note: v.note, updatedAt: v.updatedAt.toISOString() };
    });
    localStorage.setItem('surveyorNotes', JSON.stringify(notes));
  }

  loadSavedNotes() {
    const saved = localStorage.getItem('surveyorNotes');
    if (saved) {
      const notes = JSON.parse(saved);
      Object.keys(notes).forEach(k => {
        this.surveyorNotes.set(Number(k), {
          surveyorId: Number(k),
          note: notes[k].note,
          updatedAt: new Date(notes[k].updatedAt)
        });
      });
    }
  }
}
