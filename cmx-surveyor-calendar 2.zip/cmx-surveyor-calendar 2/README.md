# CMX Surveyor Availability Calendar (Angular + Spring Boot + PostgreSQL)

This starter kit gives you:
- **Dispatcher calendar** (day/week/month) in Angular using FullCalendar
- **Spring Boot API** (JDBC) with **offer TTL + atomic accept** (only one surveyor can win)
- **PostgreSQL schema** for hourly surveyor availability + offers + job assignments
- **Docker Compose** for Postgres + API + UI

## Run
```bash
docker compose up --build
```

## Open
- UI: http://localhost:4200
- API: http://localhost:8080/api/surveyors

## Key endpoints
- **Mobile posts hourly blocks**
  - `POST /api/mobile/availability`
- **FNOL creates TTL offers**
  - `POST /api/fnol/{fnolId}/offers`  (UI doc shows `<fnolId>` to avoid Angular template braces)
- **Surveyor atomic accept (only one winner)**
  - `POST /api/offers/{offerGroup}/accept`
- **Calendar feed**
  - `GET /api/availability?from=...&to=...&surveyorId=...`

## Notes on atomic accept in Postgres
This demo uses a single conditional `UPDATE ... WHERE NOT EXISTS(...)` inside a Spring `@Transactional` boundary.
In production, for stronger guarantees under extreme contention, consider:
- `SERIALIZABLE` tx isolation for the accept endpoint, **or**
- an `offer_group` winner table with a unique constraint on `offer_group` (insert-wins pattern).
