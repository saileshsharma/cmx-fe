package com.cmx.calendar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurveyorCalendarApiApplicationTests {
  @Test void contextLoads() {}
}
