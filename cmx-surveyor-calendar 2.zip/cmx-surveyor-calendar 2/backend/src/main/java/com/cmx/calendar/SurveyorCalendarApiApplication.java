package com.cmx.calendar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class SurveyorCalendarApiApplication {
  public static void main(String[] args) {
    SpringApplication.run(SurveyorCalendarApiApplication.class, args);
  }
}
