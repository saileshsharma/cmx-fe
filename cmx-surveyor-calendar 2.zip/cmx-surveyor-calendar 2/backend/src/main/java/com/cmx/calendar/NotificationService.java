package com.cmx.calendar;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@Service
public class NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationService.class);
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("EEEE, MMM d");
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("h:mm a");

    private final JdbcTemplate jdbc;
    private boolean firebaseInitialized = false;

    @Value("${firebase.credentials.path:}")
    private String firebaseCredentialsPath;

    public NotificationService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @PostConstruct
    public void initFirebase() {
        if (firebaseCredentialsPath == null || firebaseCredentialsPath.isBlank()) {
            log.warn("Firebase credentials path not configured. Push notifications disabled. " +
                    "Set FIREBASE_CREDENTIALS_PATH environment variable to enable.");
            return;
        }

        try {
            FileInputStream serviceAccount = new FileInputStream(firebaseCredentialsPath);
            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .build();

            if (FirebaseApp.getApps().isEmpty()) {
                FirebaseApp.initializeApp(options);
            }
            firebaseInitialized = true;
            log.info("Firebase initialized successfully");
        } catch (IOException e) {
            log.error("Failed to initialize Firebase: {}", e.getMessage());
        }
    }

    /**
     * Send appointment notification to a surveyor
     */
    @Async
    public void sendAppointmentNotification(Long surveyorId, String state,
                                            OffsetDateTime startTime, OffsetDateTime endTime) {
        String surveyorName = getSurveyorName(surveyorId);
        String title = "New Appointment Scheduled";
        String body = String.format("%s appointment on %s from %s to %s",
                state,
                startTime.format(DATE_FORMAT),
                startTime.format(TIME_FORMAT),
                endTime.format(TIME_FORMAT));

        Map<String, String> data = Map.of(
                "type", "APPOINTMENT_CREATED",
                "surveyorId", String.valueOf(surveyorId),
                "state", state,
                "startTime", startTime.toString(),
                "endTime", endTime.toString()
        );

        sendNotificationToSurveyor(surveyorId, title, body, data);
    }

    /**
     * Send appointment update notification
     */
    @Async
    public void sendAppointmentUpdateNotification(Long surveyorId, Long appointmentId,
                                                   OffsetDateTime startTime, OffsetDateTime endTime, String state) {
        String title = "Appointment Updated";
        String body = String.format("Your %s appointment has been updated to %s, %s - %s",
                state,
                startTime.format(DATE_FORMAT),
                startTime.format(TIME_FORMAT),
                endTime.format(TIME_FORMAT));

        Map<String, String> data = Map.of(
                "type", "APPOINTMENT_UPDATED",
                "appointmentId", String.valueOf(appointmentId),
                "surveyorId", String.valueOf(surveyorId),
                "state", state,
                "startTime", startTime.toString(),
                "endTime", endTime.toString()
        );

        sendNotificationToSurveyor(surveyorId, title, body, data);
    }

    /**
     * Send appointment deletion notification
     */
    @Async
    public void sendAppointmentDeleteNotification(Long surveyorId, Long appointmentId,
                                                   OffsetDateTime startTime, OffsetDateTime endTime) {
        String title = "Appointment Cancelled";
        String body = String.format("Your appointment on %s at %s has been cancelled",
                startTime.format(DATE_FORMAT),
                startTime.format(TIME_FORMAT));

        Map<String, String> data = Map.of(
                "type", "APPOINTMENT_DELETED",
                "appointmentId", String.valueOf(appointmentId),
                "surveyorId", String.valueOf(surveyorId)
        );

        sendNotificationToSurveyor(surveyorId, title, body, data);
    }

    /**
     * Send notification to all devices registered for a surveyor
     */
    public void sendNotificationToSurveyor(Long surveyorId, String title, String body, Map<String, String> data) {
        List<String> tokens = getDeviceTokens(surveyorId);

        if (tokens.isEmpty()) {
            log.info("No device tokens found for surveyor {}", surveyorId);
            logNotification(surveyorId, title, body, data, "NO_TOKENS", "No device tokens registered");
            return;
        }

        if (!firebaseInitialized) {
            log.warn("Firebase not initialized. Notification not sent: {} - {}", title, body);
            logNotification(surveyorId, title, body, data, "FIREBASE_DISABLED", "Firebase not initialized");
            return;
        }

        for (String token : tokens) {
            try {
                Message message = Message.builder()
                        .setNotification(Notification.builder()
                                .setTitle(title)
                                .setBody(body)
                                .build())
                        .putAllData(data)
                        .setToken(token)
                        .build();

                String response = FirebaseMessaging.getInstance().send(message);
                log.info("Notification sent successfully to surveyor {}: {}", surveyorId, response);
                logNotification(surveyorId, title, body, data, "SENT", null);

            } catch (FirebaseMessagingException e) {
                log.error("Failed to send notification to surveyor {}: {}", surveyorId, e.getMessage());
                logNotification(surveyorId, title, body, data, "FAILED", e.getMessage());

                // Remove invalid tokens
                if (e.getMessagingErrorCode() != null &&
                        (e.getMessagingErrorCode().name().equals("UNREGISTERED") ||
                         e.getMessagingErrorCode().name().equals("INVALID_ARGUMENT"))) {
                    removeDeviceToken(token);
                }
            }
        }
    }

    private List<String> getDeviceTokens(Long surveyorId) {
        return jdbc.queryForList(
                "SELECT token FROM device_token WHERE surveyor_id = ?",
                String.class,
                surveyorId
        );
    }

    private String getSurveyorName(Long surveyorId) {
        try {
            return jdbc.queryForObject(
                    "SELECT display_name FROM surveyor WHERE id = ?",
                    String.class,
                    surveyorId
            );
        } catch (Exception e) {
            return "Surveyor " + surveyorId;
        }
    }

    private void removeDeviceToken(String token) {
        jdbc.update("DELETE FROM device_token WHERE token = ?", token);
        log.info("Removed invalid device token");
    }

    private void logNotification(Long surveyorId, String title, String body,
                                  Map<String, String> data, String status, String errorMessage) {
        try {
            String dataJson = data != null ?
                    "{" + data.entrySet().stream()
                            .map(e -> "\"" + e.getKey() + "\":\"" + e.getValue() + "\"")
                            .reduce((a, b) -> a + "," + b)
                            .orElse("") + "}" : null;

            jdbc.update(
                    "INSERT INTO notification_log (surveyor_id, title, body, data, status, error_message) " +
                    "VALUES (?, ?, ?, CAST(? AS jsonb), ?, ?)",
                    surveyorId, title, body, dataJson, status, errorMessage
            );
        } catch (Exception e) {
            log.error("Failed to log notification: {}", e.getMessage());
        }
    }
}
