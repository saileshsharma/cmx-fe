package com.cmx.calendar;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class CalendarController {

  private final JdbcTemplate jdbc;
  private final NotificationService notificationService;

  public CalendarController(JdbcTemplate jdbc, NotificationService notificationService) {
    this.jdbc = jdbc;
    this.notificationService = notificationService;
  }

  @GetMapping("/surveyors")
  public List<Map<String, Object>> listSurveyors(
      @RequestParam(value = "type", required = false) String type,
      @RequestParam(value = "currentStatus", required = false) String currentStatus) {
    // Query surveyors with their current status based on availability at current time
    String sql = """
        SELECT s.id, s.code, s.display_name, s.home_lat, s.home_lng, s.status, s.surveyor_type,
               COALESCE(
                 (SELECT a.state FROM surveyor_availability a
                  WHERE a.surveyor_id = s.id
                    AND a.start_time <= NOW()
                    AND a.end_time > NOW()
                  ORDER BY a.start_time DESC LIMIT 1),
                 'AVAILABLE'
               ) as current_status
        FROM surveyor s
        """;

    StringBuilder whereClause = new StringBuilder();
    java.util.List<Object> params = new java.util.ArrayList<>();

    // Type filter
    if (type != null && !type.isEmpty() && !"ALL".equalsIgnoreCase(type)) {
      whereClause.append(" WHERE s.surveyor_type = ?");
      params.add(type.toUpperCase());
    }

    String fullSql = sql + whereClause.toString() + " ORDER BY s.display_name";
    List<Map<String, Object>> surveyors = jdbc.queryForList(fullSql, params.toArray());

    // Filter by current status if specified
    if (currentStatus != null && !currentStatus.isEmpty() && !"ALL".equalsIgnoreCase(currentStatus)) {
      String statusFilter = currentStatus.toUpperCase();
      surveyors = surveyors.stream()
          .filter(s -> statusFilter.equals(s.get("current_status")))
          .collect(java.util.stream.Collectors.toList());
    }

    return surveyors;
  }

  @GetMapping("/availability")
  public List<Map<String, Object>> availability(@RequestParam("from") String from,
                                                @RequestParam("to") String to,
                                                @RequestParam(value="surveyorId", required=false) Long surveyorId,
                                                @RequestParam(value="surveyorIds", required=false) String surveyorIds) {
    String baseSql =
        "SELECT a.id, a.surveyor_id, a.start_time, a.end_time, a.state, a.source, a.updated_at " +
        "FROM surveyor_availability a " +
        "WHERE a.start_time < CAST(? AS timestamptz) AND a.end_time > CAST(? AS timestamptz) ";

    // Support single surveyorId
    if (surveyorId != null) {
      return jdbc.queryForList(baseSql + " AND a.surveyor_id = ? ORDER BY a.surveyor_id, a.start_time",
          to, from, surveyorId);
    }

    // Support multiple surveyorIds (comma-separated)
    if (surveyorIds != null && !surveyorIds.isEmpty()) {
      String[] ids = surveyorIds.split(",");
      StringBuilder inClause = new StringBuilder(" AND a.surveyor_id IN (");
      for (int i = 0; i < ids.length; i++) {
        inClause.append(i > 0 ? ",?" : "?");
      }
      inClause.append(") ORDER BY a.surveyor_id, a.start_time");

      Object[] params = new Object[2 + ids.length];
      params[0] = to;
      params[1] = from;
      for (int i = 0; i < ids.length; i++) {
        params[2 + i] = Long.parseLong(ids[i].trim());
      }
      return jdbc.queryForList(baseSql + inClause.toString(), params);
    }

    return jdbc.queryForList(baseSql + " ORDER BY a.surveyor_id, a.start_time", to, from);
  }

  @PostMapping("/mobile/availability")
  public ResponseEntity<?> upsertAvailability(@RequestBody AvailabilityUpsertRequest req) {
    String upsert =
        "INSERT INTO surveyor_availability (surveyor_id, start_time, end_time, state, source, updated_at) " +
        "VALUES (?, CAST(? AS timestamptz), CAST(? AS timestamptz), ?, 'MOBILE', now()) " +
        "ON CONFLICT (surveyor_id, start_time, end_time) " +
        "DO UPDATE SET state = EXCLUDED.state, source = 'MOBILE', updated_at = now()";

    for (AvailabilityBlock b : req.blocks()) {
      jdbc.update(upsert, req.surveyorId(), b.startTime(), b.endTime(), b.state());

      // Send push notification for new appointment
      OffsetDateTime start = OffsetDateTime.parse(b.startTime());
      OffsetDateTime end = OffsetDateTime.parse(b.endTime());
      notificationService.sendAppointmentNotification(req.surveyorId(), b.state(), start, end);
    }
    return ResponseEntity.ok(Map.of("ok", true));
  }

  @PostMapping("/fnol/{fnolId}/offers")
  public ResponseEntity<?> createOffers(@PathVariable("fnolId") String fnolId, @RequestBody CreateOfferRequest req) {
    OffsetDateTime now = OffsetDateTime.now();
    OffsetDateTime expiresAt = now.plusSeconds(req.ttlSeconds());
    UUID offerGroup = UUID.randomUUID();

    for (Long surveyorId : req.candidateSurveyorIds()) {
      jdbc.update(
          "INSERT INTO dispatch_offer (offer_group, fnol_id, surveyor_id, status, created_at, expires_at) " +
          "VALUES (CAST(? AS uuid), ?, ?, 'PENDING', now(), ?)",
          offerGroup.toString(), fnolId, surveyorId, expiresAt
      );
    }
    return ResponseEntity.ok(Map.of("offerGroup", offerGroup.toString(), "expiresAt", expiresAt.toString()));
  }

  @PostMapping("/offers/{offerGroup}/accept")
  @Transactional
  public ResponseEntity<?> acceptOffer(@PathVariable("offerGroup") String offerGroup, @RequestBody AcceptOfferRequest req) {

    int updated = jdbc.update(
        "UPDATE dispatch_offer " +
        "SET status = 'ACCEPTED', accepted_at = now() " +
        "WHERE offer_group = CAST(? AS uuid) " +
        "  AND surveyor_id = ? " +
        "  AND status = 'PENDING' " +
        "  AND expires_at > now() " +
        "  AND NOT EXISTS ( " +
        "    SELECT 1 FROM dispatch_offer o2 " +
        "    WHERE o2.offer_group = dispatch_offer.offer_group AND o2.status = 'ACCEPTED' " +
        "  )",
        offerGroup, req.surveyorId()
    );

    if (updated != 1) {
      return ResponseEntity.status(409).body(Map.of("ok", false, "reason", "Offer already taken or expired"));
    }

    OffsetDateTime start = OffsetDateTime.now();
    OffsetDateTime end = start.plusHours(2);

    KeyHolder kh = new GeneratedKeyHolder();
    jdbc.update(con -> {
      PreparedStatement ps = con.prepareStatement(
          "INSERT INTO job_assignment (offer_group, fnol_id, surveyor_id, status, start_time, end_time, created_at) " +
          "SELECT CAST(? AS uuid), fnol_id, ?, 'ASSIGNED', ?, ?, now() " +
          "FROM dispatch_offer " +
          "WHERE offer_group = CAST(? AS uuid) AND surveyor_id = ? AND status = 'ACCEPTED'",
          Statement.RETURN_GENERATED_KEYS
      );
      ps.setString(1, offerGroup);
      ps.setLong(2, req.surveyorId());
      ps.setObject(3, start);
      ps.setObject(4, end);
      ps.setString(5, offerGroup);
      ps.setLong(6, req.surveyorId());
      return ps;
    }, kh);

    jdbc.update(
        "INSERT INTO surveyor_availability (surveyor_id, start_time, end_time, state, source, updated_at) " +
        "VALUES (?, ?, ?, 'BUSY', 'CMX', now())",
        req.surveyorId(), start, end
    );

    jdbc.update(
        "UPDATE dispatch_offer SET status = 'CLOSED' " +
        "WHERE offer_group = CAST(? AS uuid) AND status = 'PENDING'",
        offerGroup
    );

    return ResponseEntity.ok(Map.of("ok", true, "jobId", kh.getKey()));
  }

  @PostMapping("/jobs/{jobId}/complete")
  public ResponseEntity<?> complete(@PathVariable("jobId") Long jobId) {
    int u = jdbc.update(
        "UPDATE job_assignment SET status = 'COMPLETED', completed_at = now() " +
        "WHERE id = ? AND status = 'ASSIGNED'",
        jobId
    );
    return ResponseEntity.ok(Map.of("ok", u == 1));
  }

  @DeleteMapping("/availability/{id}")
  public ResponseEntity<?> deleteAvailability(@PathVariable("id") Long id) {
    // Get appointment details before deleting for notification
    Map<String, Object> appointment = null;
    try {
      appointment = jdbc.queryForMap(
          "SELECT surveyor_id, start_time, end_time FROM surveyor_availability WHERE id = ?", id);
    } catch (Exception ignored) {}

    int deleted = jdbc.update("DELETE FROM surveyor_availability WHERE id = ?", id);

    // Send notification if deletion was successful
    if (deleted == 1 && appointment != null) {
      Long surveyorId = ((Number) appointment.get("surveyor_id")).longValue();
      OffsetDateTime startTime = (OffsetDateTime) appointment.get("start_time");
      OffsetDateTime endTime = (OffsetDateTime) appointment.get("end_time");
      notificationService.sendAppointmentDeleteNotification(surveyorId, id, startTime, endTime);
    }

    return ResponseEntity.ok(Map.of("ok", deleted == 1));
  }

  @PutMapping("/availability/{id}")
  public ResponseEntity<?> updateAvailability(@PathVariable("id") Long id, @RequestBody AvailabilityUpdateRequest req) {
    // Get surveyor_id for notification
    Long surveyorId = null;
    try {
      surveyorId = jdbc.queryForObject(
          "SELECT surveyor_id FROM surveyor_availability WHERE id = ?", Long.class, id);
    } catch (Exception ignored) {}

    int updated = jdbc.update(
        "UPDATE surveyor_availability SET start_time = CAST(? AS timestamptz), end_time = CAST(? AS timestamptz), " +
        "state = ?, updated_at = now() WHERE id = ?",
        req.startTime(), req.endTime(), req.state(), id
    );

    // Send notification if update was successful
    if (updated == 1 && surveyorId != null) {
      OffsetDateTime start = OffsetDateTime.parse(req.startTime());
      OffsetDateTime end = OffsetDateTime.parse(req.endTime());
      notificationService.sendAppointmentUpdateNotification(surveyorId, id, start, end, req.state());
    }

    return ResponseEntity.ok(Map.of("ok", updated == 1));
  }

  // Device token registration for push notifications
  @PostMapping("/mobile/device-token")
  public ResponseEntity<?> registerDeviceToken(@RequestBody DeviceTokenRequest req) {
    String upsert =
        "INSERT INTO device_token (surveyor_id, token, platform, updated_at) " +
        "VALUES (?, ?, ?, now()) " +
        "ON CONFLICT (surveyor_id, token) " +
        "DO UPDATE SET platform = EXCLUDED.platform, updated_at = now()";

    jdbc.update(upsert, req.surveyorId(), req.token(), req.platform());
    return ResponseEntity.ok(Map.of("ok", true));
  }

  @DeleteMapping("/mobile/device-token")
  public ResponseEntity<?> unregisterDeviceToken(@RequestBody DeviceTokenRequest req) {
    int deleted = jdbc.update(
        "DELETE FROM device_token WHERE surveyor_id = ? AND token = ?",
        req.surveyorId(), req.token()
    );
    return ResponseEntity.ok(Map.of("ok", deleted >= 0));
  }

  // Get notification history for a surveyor
  @GetMapping("/mobile/notifications")
  public List<Map<String, Object>> getNotifications(
      @RequestParam("surveyorId") Long surveyorId,
      @RequestParam(value = "limit", defaultValue = "50") int limit) {
    return jdbc.queryForList(
        "SELECT id, title, body, data, status, created_at " +
        "FROM notification_log WHERE surveyor_id = ? " +
        "ORDER BY created_at DESC LIMIT ?",
        surveyorId, limit
    );
  }

  public record AvailabilityUpdateRequest(
      @NotBlank String startTime,
      @NotBlank String endTime,
      @NotBlank String state
  ) {}

  public record AvailabilityUpsertRequest(
      @NotNull Long surveyorId,
      @NotNull List<AvailabilityBlock> blocks
  ) {}

  public record AvailabilityBlock(
      @NotBlank String startTime,
      @NotBlank String endTime,
      @NotBlank @Size(max = 16) String state
  ) {}

  public record CreateOfferRequest(
      @NotNull List<Long> candidateSurveyorIds,
      long ttlSeconds
  ) {}

  public record AcceptOfferRequest(@NotNull Long surveyorId) {}

  public record DeviceTokenRequest(
      @NotNull Long surveyorId,
      @NotBlank String token,
      @NotBlank String platform  // ANDROID or IOS
  ) {}
}
